package com.fiap.autoescola.domain.enums;

public enum MotivoCancelamento {
    ALUNO_DESISTIU, INSTRUTOR_CANCELOU, OUTROS
}
