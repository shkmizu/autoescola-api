package com.fiap.autoescola.dto.instrutor;

import com.fiap.autoescola.domain.enums.Especialidade;

public class InstrutorResponseDTO {
    public Long id;
    public String nome;
    public String email;
    public String cnh;
    public Especialidade especialidade;
}
