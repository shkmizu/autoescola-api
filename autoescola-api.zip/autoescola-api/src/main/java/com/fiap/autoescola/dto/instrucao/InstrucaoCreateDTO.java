package com.fiap.autoescola.dto.instrucao;

import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

public class InstrucaoCreateDTO {
    @NotNull public Long alunoId;
    public Long instrutorId; // opcional
    @NotNull public LocalDateTime dataHora; // horário da instrução (1h de duração)
}
