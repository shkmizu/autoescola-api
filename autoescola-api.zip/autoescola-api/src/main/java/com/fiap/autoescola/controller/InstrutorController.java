package com.fiap.autoescola.controller;

import com.fiap.autoescola.domain.entity.Instrutor;
import com.fiap.autoescola.dto.instrutor.InstrutorCreateDTO;
import com.fiap.autoescola.dto.instrutor.InstrutorResponseDTO;
import com.fiap.autoescola.dto.instrutor.InstrutorUpdateDTO;
import com.fiap.autoescola.mapper.InstrutorMapper;
import com.fiap.autoescola.service.InstrutorService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/instrutores")
public class InstrutorController {

    private final InstrutorService service;

    public InstrutorController(InstrutorService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<InstrutorResponseDTO> criar(@Valid @RequestBody InstrutorCreateDTO dto) {
        Instrutor e = service.criar(dto);
        return ResponseEntity.ok(InstrutorMapper.toResponseDTO(e));
    }

    @GetMapping
    public ResponseEntity<Page<InstrutorResponseDTO>> listar(@RequestParam(defaultValue = "0") int page,
                                                             @RequestParam(defaultValue = "10") int size) {
        Page<InstrutorResponseDTO> resp = service.listar(page, size).map(InstrutorMapper::toResponseDTO);
        return ResponseEntity.ok(resp);
    }

    @PutMapping("/{id}")
    public ResponseEntity<InstrutorResponseDTO> atualizar(@PathVariable Long id, @Valid @RequestBody InstrutorUpdateDTO dto) {
        Instrutor e = service.atualizar(id, dto);
        return ResponseEntity.ok(InstrutorMapper.toResponseDTO(e));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
