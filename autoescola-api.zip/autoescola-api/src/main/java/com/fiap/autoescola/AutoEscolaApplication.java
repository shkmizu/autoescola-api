package com.fiap.autoescola;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutoEscolaApplication {
    public static void main(String[] args) {
        SpringApplication.run(AutoEscolaApplication.class, args);
    }
}
