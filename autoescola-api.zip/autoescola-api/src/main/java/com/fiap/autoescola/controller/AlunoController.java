package com.fiap.autoescola.controller;

import com.fiap.autoescola.domain.entity.Aluno;
import com.fiap.autoescola.dto.aluno.AlunoCreateDTO;
import com.fiap.autoescola.dto.aluno.AlunoResponseDTO;
import com.fiap.autoescola.dto.aluno.AlunoUpdateDTO;
import com.fiap.autoescola.mapper.AlunoMapper;
import com.fiap.autoescola.service.AlunoService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/alunos")
public class AlunoController {

    private final AlunoService service;

    public AlunoController(AlunoService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<AlunoResponseDTO> criar(@Valid @RequestBody AlunoCreateDTO dto) {
        Aluno e = service.criar(dto);
        return ResponseEntity.ok(AlunoMapper.toResponseDTO(e));
    }

    @GetMapping
    public ResponseEntity<Page<AlunoResponseDTO>> listar(@RequestParam(defaultValue = "0") int page,
                                                         @RequestParam(defaultValue = "10") int size) {
        Page<AlunoResponseDTO> resp = service.listar(page, size).map(AlunoMapper::toResponseDTO);
        return ResponseEntity.ok(resp);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AlunoResponseDTO> atualizar(@PathVariable Long id, @Valid @RequestBody AlunoUpdateDTO dto) {
        Aluno e = service.atualizar(id, dto);
        return ResponseEntity.ok(AlunoMapper.toResponseDTO(e));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
