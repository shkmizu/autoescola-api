package com.fiap.autoescola.controller;

import com.fiap.autoescola.domain.entity.Instrucao;
import com.fiap.autoescola.domain.enums.MotivoCancelamento;
import com.fiap.autoescola.dto.instrucao.InstrucaoCreateDTO;
import com.fiap.autoescola.dto.instrucao.InstrucaoResponseDTO;
import com.fiap.autoescola.mapper.InstrucaoMapper;
import com.fiap.autoescola.service.InstrucaoService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/instrucoes")
public class InstrucaoController {

    private final InstrucaoService service;

    public InstrucaoController(InstrucaoService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<InstrucaoResponseDTO> agendar(@Valid @RequestBody InstrucaoCreateDTO dto) {
        Instrucao e = service.agendar(dto);
        return ResponseEntity.ok(InstrucaoMapper.toResponseDTO(e));
    }

    @PostMapping("/{id}/cancelar")
    public ResponseEntity<InstrucaoResponseDTO> cancelar(@PathVariable Long id,
                                                         @RequestParam MotivoCancelamento motivo) {
        Instrucao e = service.cancelar(id, motivo);
        return ResponseEntity.ok(InstrucaoMapper.toResponseDTO(e));
    }
}
