package com.fiap.autoescola.service;

import com.fiap.autoescola.domain.entity.Instrutor;
import com.fiap.autoescola.dto.instrutor.InstrutorCreateDTO;
import com.fiap.autoescola.dto.instrutor.InstrutorUpdateDTO;
import com.fiap.autoescola.mapper.InstrutorMapper;
import com.fiap.autoescola.repository.InstrutorRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class InstrutorService {

    private final InstrutorRepository repo;

    public InstrutorService(InstrutorRepository repo) {
        this.repo = repo;
    }

    @Transactional
    public Instrutor criar(InstrutorCreateDTO dto) {
        if (repo.existsByEmail(dto.email)) {
            throw new IllegalArgumentException("E-mail já cadastrado para outro instrutor.");
        }
        if (repo.existsByCnh(dto.cnh)) {
            throw new IllegalArgumentException("CNH já cadastrada para outro instrutor.");
        }
        Instrutor e = InstrutorMapper.toEntity(dto);
        return repo.save(e);
    }

    @Transactional(readOnly = true)
    public Page<Instrutor> listar(int page, int size) {
        if (size <= 0) size = 10;
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.ASC, "nome"));
        return repo.findByAtivoTrue(pageable);
    }

    @Transactional
    public Instrutor atualizar(Long id, InstrutorUpdateDTO dto) {
        Instrutor e = repo.findByIdAndAtivoTrue(id).orElseThrow(() -> new IllegalArgumentException("Instrutor não encontrado ou inativo."));
        // Regras: não permitir alteração de email, cnh, especialidade
        InstrutorMapper.updateEntity(e, dto);
        return repo.save(e);
    }

    @Transactional
    public void excluir(Long id) {
        Instrutor e = repo.findByIdAndAtivoTrue(id).orElseThrow(() -> new IllegalArgumentException("Instrutor não encontrado ou inativo."));
        e.setAtivo(false);
        repo.save(e);
    }

    @Transactional(readOnly = true)
    public Instrutor obterAtivo(Long id) {
        return repo.findByIdAndAtivoTrue(id).orElseThrow(() -> new IllegalArgumentException("Instrutor não encontrado ou inativo."));
    }

    @Transactional(readOnly = true)
    public java.util.List<Instrutor> listarAtivos() {
        return repo.findByAtivoTrue();
    }
}
