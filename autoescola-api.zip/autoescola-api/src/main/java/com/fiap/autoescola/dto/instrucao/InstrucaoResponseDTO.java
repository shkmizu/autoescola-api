package com.fiap.autoescola.dto.instrucao;

import com.fiap.autoescola.domain.enums.MotivoCancelamento;
import java.time.LocalDateTime;

public class InstrucaoResponseDTO {
    public Long id;
    public Long alunoId;
    public Long instrutorId;
    public LocalDateTime dataHora;
    public Boolean cancelada;
    public MotivoCancelamento motivoCancelamento;
    public LocalDateTime canceladaEm;
}
