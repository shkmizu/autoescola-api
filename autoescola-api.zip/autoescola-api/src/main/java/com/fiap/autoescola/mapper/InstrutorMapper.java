package com.fiap.autoescola.mapper;

import com.fiap.autoescola.domain.entity.Instrutor;
import com.fiap.autoescola.domain.vo.Endereco;
import com.fiap.autoescola.dto.EnderecoDTO;
import com.fiap.autoescola.dto.instrutor.InstrutorCreateDTO;
import com.fiap.autoescola.dto.instrutor.InstrutorResponseDTO;
import com.fiap.autoescola.dto.instrutor.InstrutorUpdateDTO;

public class InstrutorMapper {
    public static Instrutor toEntity(InstrutorCreateDTO dto) {
        Instrutor e = new Instrutor();
        e.setNome(dto.nome);
        e.setEmail(dto.email);
        e.setCnh(dto.cnh);
        e.setEspecialidade(dto.especialidade);
        e.setEndereco(toEndereco(dto.endereco));
        return e;
    }

    public static void updateEntity(Instrutor entity, InstrutorUpdateDTO dto) {
        entity.setNome(dto.nome);
        entity.setTelefone(dto.telefone);
        entity.setEndereco(toEndereco(dto.endereco));
    }

    public static InstrutorResponseDTO toResponseDTO(Instrutor e) {
        InstrutorResponseDTO r = new InstrutorResponseDTO();
        r.id = e.getId();
        r.nome = e.getNome();
        r.email = e.getEmail();
        r.cnh = e.getCnh();
        r.especialidade = e.getEspecialidade();
        return r;
    }

    private static Endereco toEndereco(EnderecoDTO d) {
        Endereco end = new Endereco();
        end.setLogradouro(d.logradouro);
        end.setNumero(d.numero);
        end.setComplemento(d.complemento);
        end.setBairro(d.bairro);
        end.setCidade(d.cidade);
        end.setUf(d.uf);
        end.setCep(d.cep);
        return end;
    }
}
