package com.fiap.autoescola.service;

import com.fiap.autoescola.domain.entity.Aluno;
import com.fiap.autoescola.domain.entity.Instrucao;
import com.fiap.autoescola.domain.entity.Instrutor;
import com.fiap.autoescola.domain.enums.MotivoCancelamento;
import com.fiap.autoescola.dto.instrucao.InstrucaoCreateDTO;
import com.fiap.autoescola.mapper.InstrucaoMapper;
import com.fiap.autoescola.repository.AlunoRepository;
import com.fiap.autoescola.repository.InstrucaoRepository;
import com.fiap.autoescola.repository.InstrutorRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.*;
import java.util.List;
import java.util.Random;

@Service
public class InstrucaoService {

    private final InstrucaoRepository instrucaoRepo;
    private final AlunoRepository alunoRepo;
    private final InstrutorRepository instrutorRepo;
    private final Random random = new Random();

    private static final LocalTime ABRE = LocalTime.of(6, 0);
    private static final LocalTime FECHA = LocalTime.of(21, 0);
    private static final ZoneId ZONE = ZoneId.of("America/Sao_Paulo");

    public InstrucaoService(InstrucaoRepository instrucaoRepo, AlunoRepository alunoRepo, InstrutorRepository instrutorRepo) {
        this.instrucaoRepo = instrucaoRepo;
        this.alunoRepo = alunoRepo;
        this.instrutorRepo = instrutorRepo;
    }

    @Transactional
    public Instrucao agendar(InstrucaoCreateDTO dto) {
        Aluno aluno = alunoRepo.findByIdAndAtivoTrue(dto.alunoId)
                .orElseThrow(() -> new IllegalArgumentException("Aluno não encontrado ou inativo."));

        LocalDateTime dataHora = dto.dataHora;
        if (dataHora == null) throw new IllegalArgumentException("Data/Hora é obrigatória.");

        // 30 min de antecedência
        LocalDateTime agora = LocalDateTime.now(ZONE);
        if (dataHora.isBefore(agora.plusMinutes(30))) {
            throw new IllegalArgumentException("A instrução deve ser agendada com antecedência mínima de 30 minutos.");
        }

        // Segunda a Sábado
        DayOfWeek dow = dataHora.getDayOfWeek();
        if (dow == DayOfWeek.SUNDAY) {
            throw new IllegalArgumentException("Agendamento apenas de segunda a sábado.");
        }

        // Janela 06:00 às 21:00 (1h de duração, então início deve ser <= 20:00)
        LocalTime inicio = dataHora.toLocalTime();
        if (inicio.isBefore(ABRE) || !inicio.isBefore(FECHA)) { // inicio >= 21:00 não pode
            throw new IllegalArgumentException("Horário fora do funcionamento (06:00 às 21:00).");
        }

        // Máximo de 2 instruções por dia por aluno
        LocalDate dia = dataHora.toLocalDate();
        LocalDateTime inicioDia = dia.atStartOfDay();
        LocalDateTime fimDia = dia.atTime(23, 59, 59);
        long qtdAlunoDia = instrucaoRepo.countByAlunoAndDataHoraBetweenAndCanceladaFalse(aluno, inicioDia, fimDia);
        if (qtdAlunoDia >= 2) {
            throw new IllegalArgumentException("O aluno já possui duas instruções neste dia.");
        }

        Instrutor instrutor = null;
        if (dto.instrutorId != null) {
            instrutor = instrutorRepo.findByIdAndAtivoTrue(dto.instrutorId)
                    .orElseThrow(() -> new IllegalArgumentException("Instrutor não encontrado ou inativo."));
            if (instrucaoRepo.existsByInstrutorAndDataHoraAndCanceladaFalse(instrutor, dataHora)) {
                throw new IllegalArgumentException("Instrutor indisponível neste horário.");
            }
        } else {
            // escolher aleatoriamente um instrutor disponível
            List<Instrutor> ativos = instrutorRepo.findByAtivoTrue();
            java.util.List<Instrutor> disponiveis = new java.util.ArrayList<>();
            for (Instrutor i : ativos) {
                if (!instrucaoRepo.existsByInstrutorAndDataHoraAndCanceladaFalse(i, dataHora)) {
                    disponiveis.add(i);
                }
            }
            if (disponiveis.isEmpty()) {
                throw new IllegalArgumentException("Nenhum instrutor disponível para a data/hora informada.");
            }
            instrutor = disponiveis.get(random.nextInt(disponiveis.size()));
        }

        Instrucao instr = new Instrucao();
        instr.setAluno(aluno);
        instr.setInstrutor(instrutor);
        instr.setDataHora(dataHora);
        return instrucaoRepo.save(instr);
    }

    @Transactional
    public Instrucao cancelar(Long instrucaoId, MotivoCancelamento motivo) {
        Instrucao instr = instrucaoRepo.findById(instrucaoId)
                .orElseThrow(() -> new IllegalArgumentException("Instrução não encontrada."));

        if (instr.getCancelada() != null && instr.getCancelada()) {
            throw new IllegalArgumentException("Instrução já cancelada.");
        }
        if (motivo == null) {
            throw new IllegalArgumentException("Motivo do cancelamento é obrigatório.");
        }

        LocalDateTime agora = LocalDateTime.now(ZONE);
        // antecedência mínima de 24 horas
        if (!agora.isBefore(instr.getDataHora().minusHours(24))) {
            throw new IllegalArgumentException("Cancelamento somente com 24 horas de antecedência mínima.");
        }

        instr.setCancelada(true);
        instr.setMotivoCancelamento(motivo);
        instr.setCanceladaEm(agora);
        return instrucaoRepo.save(instr);
    }
}
