package com.fiap.autoescola.mapper;

import com.fiap.autoescola.domain.entity.Instrucao;
import com.fiap.autoescola.dto.instrucao.InstrucaoResponseDTO;

public class InstrucaoMapper {
    public static InstrucaoResponseDTO toResponseDTO(Instrucao e) {
        InstrucaoResponseDTO r = new InstrucaoResponseDTO();
        r.id = e.getId();
        r.alunoId = e.getAluno() != null ? e.getAluno().getId() : null;
        r.instrutorId = e.getInstrutor() != null ? e.getInstrutor().getId() : null;
        r.dataHora = e.getDataHora();
        r.cancelada = e.getCancelada();
        r.motivoCancelamento = e.getMotivoCancelamento();
        r.canceladaEm = e.getCanceladaEm();
        return r;
    }
}
