package com.fiap.autoescola.service;

import com.fiap.autoescola.domain.entity.Aluno;
import com.fiap.autoescola.dto.aluno.AlunoCreateDTO;
import com.fiap.autoescola.dto.aluno.AlunoUpdateDTO;
import com.fiap.autoescola.mapper.AlunoMapper;
import com.fiap.autoescola.repository.AlunoRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AlunoService {

    private final AlunoRepository repo;

    public AlunoService(AlunoRepository repo) {
        this.repo = repo;
    }

    @Transactional
    public Aluno criar(AlunoCreateDTO dto) {
        if (repo.existsByEmail(dto.email)) {
            throw new IllegalArgumentException("E-mail já cadastrado para outro aluno.");
        }
        if (repo.existsByCpf(dto.cpf)) {
            throw new IllegalArgumentException("CPF já cadastrado para outro aluno.");
        }
        Aluno e = AlunoMapper.toEntity(dto);
        return repo.save(e);
    }

    @Transactional(readOnly = true)
    public Page<Aluno> listar(int page, int size) {
        if (size <= 0) size = 10;
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.ASC, "nome"));
        return repo.findByAtivoTrue(pageable);
    }

    @Transactional
    public Aluno atualizar(Long id, AlunoUpdateDTO dto) {
        Aluno e = repo.findByIdAndAtivoTrue(id).orElseThrow(() -> new IllegalArgumentException("Aluno não encontrado ou inativo."));
        // Regras: não permitir alteração de email, cpf
        AlunoMapper.updateEntity(e, dto);
        return repo.save(e);
    }

    @Transactional
    public void excluir(Long id) {
        Aluno e = repo.findByIdAndAtivoTrue(id).orElseThrow(() -> new IllegalArgumentException("Aluno não encontrado ou inativo."));
        e.setAtivo(false);
        repo.save(e);
    }

    @Transactional(readOnly = true)
    public Aluno obterAtivo(Long id) {
        return repo.findByIdAndAtivoTrue(id).orElseThrow(() -> new IllegalArgumentException("Aluno não encontrado ou inativo."));
    }
}
