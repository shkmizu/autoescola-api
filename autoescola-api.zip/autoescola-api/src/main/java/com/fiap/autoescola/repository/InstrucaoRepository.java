package com.fiap.autoescola.repository;

import com.fiap.autoescola.domain.entity.Instrucao;
import com.fiap.autoescola.domain.entity.Instrutor;
import com.fiap.autoescola.domain.entity.Aluno;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface InstrucaoRepository extends JpaRepository<Instrucao, Long> {
    boolean existsByInstrutorAndDataHoraAndCanceladaFalse(Instrutor instrutor, LocalDateTime dataHora);
    long countByAlunoAndDataHoraBetweenAndCanceladaFalse(Aluno aluno, LocalDateTime inicio, LocalDateTime fim);
    List<Instrucao> findByInstrutorAndDataHoraBetweenAndCanceladaFalse(Instrutor instrutor, LocalDateTime inicio, LocalDateTime fim);
}
