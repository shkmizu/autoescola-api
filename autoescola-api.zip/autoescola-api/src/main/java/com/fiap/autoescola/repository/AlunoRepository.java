package com.fiap.autoescola.repository;

import com.fiap.autoescola.domain.entity.Aluno;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AlunoRepository extends JpaRepository<Aluno, Long> {
    Page<Aluno> findByAtivoTrue(Pageable pageable);
    Optional<Aluno> findByIdAndAtivoTrue(Long id);
    boolean existsByEmail(String email);
    boolean existsByCpf(String cpf);
}
