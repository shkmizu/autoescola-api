package com.fiap.autoescola.domain.entity;

import com.fiap.autoescola.domain.entity.Aluno;
import com.fiap.autoescola.domain.entity.Instrutor;
import com.fiap.autoescola.domain.enums.MotivoCancelamento;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Instrucao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Aluno aluno;

    @ManyToOne
    private Instrutor instrutor; // opcional no agendamento

    @Column(nullable = false)
    private LocalDateTime dataHora;

    private Boolean cancelada = false;

    @Enumerated(EnumType.STRING)
    private MotivoCancelamento motivoCancelamento;

    private LocalDateTime canceladaEm;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Aluno getAluno() { return aluno; }
    public void setAluno(Aluno aluno) { this.aluno = aluno; }

    public Instrutor getInstrutor() { return instrutor; }
    public void setInstrutor(Instrutor instrutor) { this.instrutor = instrutor; }

    public LocalDateTime getDataHora() { return dataHora; }
    public void setDataHora(LocalDateTime dataHora) { this.dataHora = dataHora; }

    public Boolean getCancelada() { return cancelada; }
    public void setCancelada(Boolean cancelada) { this.cancelada = cancelada; }

    public MotivoCancelamento getMotivoCancelamento() { return motivoCancelamento; }
    public void setMotivoCancelamento(MotivoCancelamento motivoCancelamento) { this.motivoCancelamento = motivoCancelamento; }

    public LocalDateTime getCanceladaEm() { return canceladaEm; }
    public void setCanceladaEm(LocalDateTime canceladaEm) { this.canceladaEm = canceladaEm; }
}
