package com.fiap.autoescola.mapper;

import com.fiap.autoescola.domain.entity.Aluno;
import com.fiap.autoescola.domain.vo.Endereco;
import com.fiap.autoescola.dto.EnderecoDTO;
import com.fiap.autoescola.dto.aluno.AlunoCreateDTO;
import com.fiap.autoescola.dto.aluno.AlunoUpdateDTO;
import com.fiap.autoescola.dto.aluno.AlunoResponseDTO;

public class AlunoMapper {
    public static Aluno toEntity(AlunoCreateDTO dto) {
        Aluno e = new Aluno();
        e.setNome(dto.nome);
        e.setEmail(dto.email);
        e.setTelefone(dto.telefone);
        e.setCpf(dto.cpf);
        e.setEndereco(toEndereco(dto.endereco));
        return e;
    }

    public static void updateEntity(Aluno entity, AlunoUpdateDTO dto) {
        entity.setNome(dto.nome);
        entity.setTelefone(dto.telefone);
        entity.setEndereco(toEndereco(dto.endereco));
    }

    public static AlunoResponseDTO toResponseDTO(Aluno e) {
        AlunoResponseDTO r = new AlunoResponseDTO();
        r.id = e.getId();
        r.nome = e.getNome();
        r.email = e.getEmail();
        r.cpf = e.getCpf();
        return r;
    }

    private static Endereco toEndereco(EnderecoDTO d) {
        Endereco end = new Endereco();
        end.setLogradouro(d.logradouro);
        end.setNumero(d.numero);
        end.setComplemento(d.complemento);
        end.setBairro(d.bairro);
        end.setCidade(d.cidade);
        end.setUf(d.uf);
        end.setCep(d.cep);
        return end;
    }
}
