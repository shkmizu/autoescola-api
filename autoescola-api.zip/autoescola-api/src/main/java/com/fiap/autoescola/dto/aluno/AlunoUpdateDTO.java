package com.fiap.autoescola.dto.aluno;

import com.fiap.autoescola.dto.EnderecoDTO;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class AlunoUpdateDTO {
    @NotBlank public String nome;
    @NotBlank public String telefone;
    @NotNull public EnderecoDTO endereco;
}
