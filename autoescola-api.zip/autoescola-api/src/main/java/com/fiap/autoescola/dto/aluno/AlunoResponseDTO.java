package com.fiap.autoescola.dto.aluno;

public class AlunoResponseDTO {
    public Long id;
    public String nome;
    public String email;
    public String cpf;
}
