package com.fiap.autoescola.dto.instrutor;

import com.fiap.autoescola.domain.enums.Especialidade;
import com.fiap.autoescola.dto.EnderecoDTO;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class InstrutorCreateDTO {
    @NotBlank public String nome;
    @NotBlank @Email public String email;
    // telefone não é requerido na criação (oculto inicialmente)
    @NotBlank public String cnh;
    @NotNull public Especialidade especialidade;
    @NotNull public EnderecoDTO endereco;
}
