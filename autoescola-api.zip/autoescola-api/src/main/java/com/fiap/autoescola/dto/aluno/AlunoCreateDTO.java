package com.fiap.autoescola.dto.aluno;

import com.fiap.autoescola.dto.EnderecoDTO;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class AlunoCreateDTO {
    @NotBlank public String nome;
    @NotBlank @Email public String email;
    @NotBlank public String telefone;
    @NotBlank public String cpf;
    @NotNull public EnderecoDTO endereco;
}
