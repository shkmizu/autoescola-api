package com.fiap.autoescola.dto;

import jakarta.validation.constraints.NotBlank;

public class EnderecoDTO {
    @NotBlank public String logradouro;
    public String numero; // opcional
    public String complemento; // opcional
    @NotBlank public String bairro;
    @NotBlank public String cidade;
    @NotBlank public String uf;
    @NotBlank public String cep;
}
