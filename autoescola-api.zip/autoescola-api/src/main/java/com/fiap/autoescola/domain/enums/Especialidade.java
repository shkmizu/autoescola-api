package com.fiap.autoescola.domain.enums;

public enum Especialidade {
    MOTOS, CARROS, VANS, CAMINHOES
}
