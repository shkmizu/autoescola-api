package com.fiap.autoescola.dto.instrutor;

import com.fiap.autoescola.dto.EnderecoDTO;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class InstrutorUpdateDTO {
    @NotBlank public String nome;
    public String telefone; // agora pode ser informado
    @NotNull public EnderecoDTO endereco;
}
